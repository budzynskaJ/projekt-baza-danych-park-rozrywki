function successfullyLogout(){
    alert("Zostałeś pomyślnie wylogowany");
}